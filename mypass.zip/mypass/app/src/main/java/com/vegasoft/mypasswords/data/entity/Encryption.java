package com.vegasoft.mypasswords.data.entity;

public enum Encryption {
    RSA,
    AES;
}
