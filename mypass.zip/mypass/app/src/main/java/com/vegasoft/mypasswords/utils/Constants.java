package com.vegasoft.mypasswords.utils;

public class Constants {
}
